import java.io.*;
import java.sql.*;
/*
create table 学生表(
学号 int(20) primary key,
姓名 varchar(25) not null,
班级 varchar(25) not null,
年龄 int(3) check(年龄>=0 and 年龄<150),
性别 enum('男','女') not null,
出生日期 varchar(25),
地址 varchar(50),
电话 varchar(16),
邮箱 varchar(30),
学院 varchar(16)
);
 */
class ConnectSQL {
    private String table;
    private Connection _connection=null;
    private Statement _statement=null;
    private ResultSet _resultSet=null;
    boolean LianjieSQL(String user,String password,String duankou,String database){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:"+duankou+"/"+database+"? useSSL=false&characterEncoding=utf-8";
            _connection=DriverManager.getConnection(url,user,password);
            _statement=_connection.createStatement();
        } catch (Exception e) {
            return false;
        }
        return true;
    }
    boolean CloseSQL(boolean have_res){//是否含有ResultSet
        if(have_res){
            try {
                _resultSet.close();
                _statement.close();
                _connection.close();
            } catch (SQLException e) {
                return false;
            }
            return true;
        }else{
            try {
                _statement.close();
                _connection.close();
            } catch (SQLException e) {
                return false;
            }
            return true;
        }
    }

    public ConnectSQL(String table) {
        this.table=table;
    }

    private Statement get_statement() {
        return _statement;
    }

    private ResultSet get_resultSet() {
        return _resultSet;
    }

    boolean add_stu(Long sno,String name,String sclass,int age,String sex,String date,String dizhi,String phone,String email,String dept){
        if(_statement==null){
            return false;
        }else{
            StringBuffer sql=new StringBuffer("insert into "+table+" values('"+sno+"','"+name+"','"+sclass+"','"+age+"','"+sex+"','"+date+"','"+dizhi+"','"+phone+"','"+email+"','"+dept+"');");
            try {
                int count=_statement.executeUpdate(sql.toString());
                if(count>0){
                    return true;
                }else{
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
        }
    }
    int update_stu(Long[] sno,String[] date){
        if(_statement==null){
            return 0;
        }else {
            String[] command = {"学号=", "姓名=", "班级=", "年龄=", "性别=", "出生日期=", "地址=", "电话=", "邮箱=", "学院="};
            int num,count=0;
            for (int i=0;i<sno.length;i++) {//外循环几个人
                num=0;
                StringBuffer sql=new StringBuffer("update "+table+" set ");
                for (int j = 0; j < date.length; j++) {//内循环一个人的几个属性
                    if (!date[j].isEmpty()) {//让sql符合MySQL语法
                        if (num==0||num== date.length-1) {
                            num++;
                        } else {
                            sql.append(",");
                        }
                        if(j==0||j==3){
                            sql.append(command[j]).append(date[j]);
                        }else{
                            sql.append(command[j]).append("'").append(date[j]).append("'");
                        }
                    }
                }
                sql.append(" where 学号=").append(sno[i]).append(";");
                try {
                    count+=_statement.executeUpdate(sql.toString());
                    if(count<=0){
                        return 0;
                    }
                } catch (SQLException e) {
                    return  0;
                }
            }
            return count;
        }
    }
    boolean clear_table(){
        if(_statement==null){
            return false;
        }else{
            StringBuffer sql=new StringBuffer("truncate "+"`"+table+"`;");
            try {
                _statement.executeUpdate(sql.toString());
                return true;
            } catch (SQLException e) {
                return false;
            }
        }
    }
    int del_stu(Long[] sno){
        int num=0;
        if(_statement==null){
            return -1;
        }else{
            for (int i=0;i< sno.length;i++) {
                StringBuffer sql=new StringBuffer("delete from "+table+" where 学号="+sno[i]+";");
                try {
                    int count=_statement.executeUpdate(sql.toString());
                    if(count>0){
                        num+=count;
                    }
                } catch (SQLException e) {
                    return num;
                }
            }
            return num;
        }
    }
    private int getRows(Statement _statement,StringBuffer sql){
        //计算resultset查询结果的行数，若参数错误或抛出Sql异常则返回-1
        if(_statement==null){
            return -1;
        }else{
            try {
                ResultSet temp=_statement.executeQuery(sql.toString());
                int lines=0;
                while(temp.next()){
                    lines++;
                }
                return lines;
            } catch (SQLException e) {
                return -1;
            }
        }
    }
    Object[][] sel_stu(StringBuffer where) throws SQLException{
        if(_statement==null){
            throw new NullPointerException();
        }else{
            StringBuffer sql=new StringBuffer("select * from "+table+" ");
            sql.append(where);
            sql.append(";");
            int rows=getRows(_statement,sql);
            _resultSet = _statement.executeQuery(sql.toString());
            if (rows == -1||rows == 0) {
                throw new SQLException();
            }
            Object[][] temp = new String[rows][10];
            for (int i = 0; _resultSet.next(); i++) {
                temp[i][0] = _resultSet.getString("学号");
                temp[i][1] = _resultSet.getString("姓名");
                temp[i][2] = _resultSet.getString("班级");
                temp[i][3] = _resultSet.getString("年龄");
                temp[i][4] = _resultSet.getString("性别");
                temp[i][5] = _resultSet.getString("出生日期");
                temp[i][6] = _resultSet.getString("地址");
                temp[i][7] = _resultSet.getString("电话");
                temp[i][8] = _resultSet.getString("邮箱");
                temp[i][9] = _resultSet.getString("学院");
            }
            return temp;
        }
    }
    boolean dateTobackup(String file){
        try {
            FileOutputStream fos=new FileOutputStream(file);
            ObjectOutputStream oos=new ObjectOutputStream(fos);
            Dates dates=new Dates(sel_stu(new StringBuffer()));
            oos.writeObject(dates);
            return true;
        } catch (IOException | SQLException e) {
            return false;
        }
    }
    int backupTodate(String file){
        try {
            FileInputStream fis=new FileInputStream(file);
            ObjectInputStream ois=new ObjectInputStream(fis);
            Dates dates=(Dates) ois.readObject();//读取对象
            Object[][] date=dates.getDate();//获取数据
            //插入数据库实现
            int num=0;
            for (int i = 0; i < date.length; i++) {
                if(add_stu(Long.parseLong((String)date[i][0]),(String)date[i][1],(String)date[i][2],Integer.parseInt((String)date[i][3]),(String)date[i][4],(String)date[i][5],(String)date[i][6],(String)date[i][7],(String)date[i][8],(String)date[i][9])){
                    num++;
                }
            }
            return num;
        } catch (IOException | ClassNotFoundException e) {
            return -1;
        }
    }

}


class Dates implements Serializable {
    private static final long serialVersionUID=1L;
    private Object[][] date;

    Dates(Object[][] date) {
        this.date = date;
    }

    Object[][] getDate() {
        return date;
    }
}
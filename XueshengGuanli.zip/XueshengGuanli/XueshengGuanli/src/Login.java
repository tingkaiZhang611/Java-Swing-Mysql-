import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

class Login extends JFrame{
    private Login f;
    private JPanel Login_p;
    public Login() {
        super("学生信息管理系统");
        setSize(1000,650);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);
        Login_p=new M_Login_p();
        add(Login_p);
        JPanel background=new JPanel();
        background.setBounds(0,0,1000,650);
        background.add(new JLabel(new ImageIcon("F:\\Java课设\\Login.jpg")));
        add(background);
        setVisible(true);
        f=this;
    }
    class M_Login_p extends JPanel{
        public M_Login_p() {
            setLayout(null);
            setBackground(Color.white);
            setBounds(550,100,400,280);
            M_label bigTilte=new M_label("欢迎使用,请先登录！",Color.BLACK,true);
            bigTilte.setBounds(20,20,350,30);
            M_label smallTilte1=new M_label("用户名:",Color.BLACK,false);
            smallTilte1.setBounds(40,90,50,30);
            M_label smallTilte2=new M_label(" 密 码:",Color.BLACK,false);
            smallTilte2.setBounds(40,125,50,30);
            JTextField input1=new JTextField();
            JPasswordField input2=new JPasswordField();
            input1.setBounds(93,90,250,30);
            input2.setBounds(93,125,250,30);


            M_woindow.Menu_button button=new M_woindow.Menu_button("登录",Color.white,Color.decode("#DC143C"));
            button.setBounds(40,180,150,35);
            M_woindow.Menu_button button2=new M_woindow.Menu_button("清空",Color.white,Color.decode("#DC143C"));
            button2.setBounds(195,180,150,35);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if(isPass(input1.getText(),new String(input2.getPassword()))){//返回的是char[]
                        f.setVisible(false);
                        ConnectSQL sql1=new ConnectSQL("学生表");
                        if(sql1.LianjieSQL("root","123456","3306","stu_keshe")){
                            M_woindow m= new M_woindow("root_localhost:已连接到数据库",sql1);
                            f=null;
                        }else{
                            //提示退出
                            JOptionPane.showMessageDialog(new JFrame(),"数据库链接失败，请检查MySQL服务","学生信息管理系统",JOptionPane.ERROR_MESSAGE);
                            System.exit(10086);
                        }
                    }else{
                        JOptionPane.showMessageDialog(f,"用户名或密码错误！","学生信息管理系统",JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
            button2.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    input1.setText("");
                    input2.setText("");
                }
            });



            //彩蛋
            JLabel egg=new JLabel("<html><u>内有乾坤.勿点</u></html>");
            egg.setFont(new Font("微软雅黑",Font.BOLD,13));
            egg.setForeground(Color.RED);
            egg.setBounds(155,250,100,20);
            egg.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    try {
                        Clip clip = AudioSystem.getClip();
                        clip.open(AudioSystem.getAudioInputStream(new File("F:\\Java课设\\你干嘛.wav")));
                        clip.start();
                    } catch (Exception ex) {
                        ;
                    }
                }
            });
            add(bigTilte);
            add(smallTilte1);
            add(smallTilte2);
            add(input1);
            add(input2);
            add(button);
            add(button2);
            add(egg);
        }
        private boolean isPass(String zh,String password){
            return zh.equals("root") && password.equals("123456");
        }
    }
}
class M_label extends JLabel{
    public M_label(String title,Color color,boolean isBig){
        super(title);
        setForeground(color);
        if(isBig){
            setFont(new Font("微软雅黑",Font.BOLD,24));
        }else{
            setFont(new Font("微软雅黑",Font.PLAIN,15));
        }
    }
}
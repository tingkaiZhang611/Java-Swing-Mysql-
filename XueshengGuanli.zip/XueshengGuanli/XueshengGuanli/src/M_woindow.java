import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.Arrays;

class M_woindow extends JFrame{
    private Object[][] sqlData;
    private boolean has_res=false;//是否使用了ResultSet
    private boolean nullSql=true;//空的检索结果，防止调用空数组抛出异常
    private Long[] sql_update;
    private static Object[][] sql_delete;

    public M_woindow(String name, ConnectSQL sql) {
        //构建主窗口
        super(name);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        //构建顶部状态栏
        JPanel p_up = getp_up();
        //构建右卡片布局功能实现栏
        CardLayout p_right_layout = new CardLayout();
        //构建卡片布局中的容器
        Get_right get_righter =new Get_right(p_right_layout, sql);
        JPanel p_right = get_righter.getp_right;
        //构建左菜单栏
        Get_left get_lefter = new Get_left(sql, p_right_layout, p_right);
        JPanel p_left = get_lefter.getp_left;
        //设置主窗口布局管理
        setLayout(new BorderLayout());
        add(p_up, BorderLayout.NORTH);
        add(p_left, BorderLayout.WEST);
        add(p_right, BorderLayout.CENTER);
        setVisible(true);
    }

    private static JPanel getp_up() {
        JPanel p_up_temp = new JPanel();
        p_up_temp.setLayout(new GridLayout(1, 2));
        p_up_temp.setBackground(Color.decode("#1E90FF"));
        JLabel p_up_jl = new JLabel("    学生信息管理系统 v0.4.02");
        p_up_jl.setFont(new Font("微软雅黑", Font.PLAIN, 24));
        p_up_jl.setForeground(Color.white);
        p_up_temp.add(p_up_jl);
        p_up_temp.add(new JLabel(read_ico("F:\\Java课设\\用户头像.png"), JLabel.RIGHT));
        return p_up_temp;
    }

    private class Get_left {
        JPanel getp_left;
        Get_left(ConnectSQL sql, CardLayout p_right_layout, JPanel p_right) {
            JPanel p_left_temp = new JPanel();
            p_left_temp.setLayout(new GridLayout(10, 1));
            p_left_temp.setBackground(Color.darkGray);
            Menu_button b_sql = new Menu_button("学生信息查询", Color.LIGHT_GRAY, Color.DARK_GRAY);
            b_sql.setForeground(Color.white);//默认的被选择项
            b_sql.setBackground(Color.decode("#1778d7"));
            Menu_button b_add = new Menu_button("学生信息添加", Color.LIGHT_GRAY, Color.DARK_GRAY);
            Menu_button b_update = new Menu_button("更改学生信息", Color.LIGHT_GRAY, Color.DARK_GRAY);
            Menu_button b_delete = new Menu_button("学生信息删除", Color.LIGHT_GRAY, Color.DARK_GRAY);
            Menu_button b_backup = new Menu_button("系统备份与恢复", Color.LIGHT_GRAY, Color.DARK_GRAY);
            Menu_button sys_exit = new Menu_button("退出系统", Color.LIGHT_GRAY, Color.DARK_GRAY);
            Menu_button[] b_button = new Menu_button[6];
            b_button[0] = b_sql;
            b_button[1] = b_add;
            b_button[2] = b_update;
            b_button[3] = b_delete;
            b_button[4] = b_backup;
            b_button[5] = sys_exit;
            //左侧菜单栏按钮点击事件实现
            b_sql.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    p_right_layout.show(p_right, "sql");
                    b_sql.setForeground(Color.white);
                    b_sql.setBackground(Color.decode("#1778d7"));
                    reMBColor(b_sql, b_button);
                }
            });
            b_add.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    p_right_layout.show(p_right, "add");
                    b_add.setForeground(Color.white);
                    b_add.setBackground(Color.decode("#1778d7"));
                    reMBColor(b_add, b_button);
                }
            });
            b_update.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (sql_update != null) {
                        p_right_layout.show(p_right, "update");
                        b_update.setForeground(Color.white);
                        b_update.setBackground(Color.decode("#1778d7"));
                        reMBColor(b_update, b_button);
                    } else {
                        JOptionPane.showMessageDialog(p_right, "尚未从检索发送待操作的学生信息，请先检索并发送后重试！", "学生信息管理系统", JOptionPane.WARNING_MESSAGE);
                    }
                }
            });
            b_delete.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (sql_delete != null) {
                        p_right_layout.show(p_right, "delete");
                        b_delete.setForeground(Color.white);
                        b_delete.setBackground(Color.decode("#1778d7"));
                        reMBColor(b_delete, b_button);
                    } else {
                        JOptionPane.showMessageDialog(p_right, "尚未从检索发送待操作的学生信息，请先检索并发送后重试！", "学生信息管理系统", JOptionPane.WARNING_MESSAGE);
                    }
                }
            });
            b_backup.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    p_right_layout.show(p_right, "backup");
                    b_backup.setForeground(Color.white);
                    b_backup.setBackground(Color.decode("#1778d7"));
                    reMBColor(b_backup, b_button);
                }
            });
            sys_exit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    b_sql.setForeground(Color.white);
                    b_sql.setBackground(Color.decode("#1778d7"));
                    reMBColor(sys_exit, b_button);
                    if (sql.CloseSQL(has_res)) {
                        System.out.println("数据库链接已经成功断开");
                    } else {
                        System.out.println("数据库链接断开失败");
                    }
                    System.exit(0);
                }
            });

            for (int i = 0; i < b_button.length; i++) {
                p_left_temp.add(b_button[i]);
            }
            getp_left = p_left_temp;
        }
    }

    private class Get_right {
        JPanel getp_right;
        M_panel m_panel;
        JPanel p_del_table;
        JScrollPane del_table;
        Get_right(CardLayout cardLayout, ConnectSQL sql) {
            JPanel p_right_temp = new JPanel();
            p_right_temp.setLayout(cardLayout);
            JPanel p_sql = new JPanel();
            JPanel p_add = new JPanel();
            JPanel p_update = new JPanel();
            JPanel p_delete = new JPanel();
            JPanel p_backup = new JPanel();
            p_right_temp.add(p_sql, "sql");
            p_right_temp.add(p_add, "add");
            p_right_temp.add(p_update, "update");
            p_right_temp.add(p_delete, "delete");
            p_right_temp.add(p_backup, "backup");
            //p_sql容器布局实现
            p_sql.setLayout(new GridLayout(2, 1));
            p_sql.add(new M_panel("    • 请输入检索条件,为空的条件将不参与检索:", "检索", "#20B2AA") {
                @Override
                void p_action() {
                    //检索实现
                    //如果键入不为空则参与where条件
                    try {
                        sqlData = sql.sel_stu(getSqlwhere());//Mysql select where指令
                        has_res=true;
                        if (table != null) {
                            p_sql.remove(table);
                            p_sql.revalidate();
                        }
                        table = getTable(sqlData);
                        p_sql.add(table);
                        p_sql.revalidate();
                        nullSql=false;//将空搜索结果设置为假
                        JOptionPane.showMessageDialog(this, "检索成功.共检索到" + sqlData.length + "条结果.", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                    } catch (SQLException e) {
                        //处理检索失败;
                        nullSql=true;
                        if (table != null) {
                            p_sql.remove(table);
                            p_sql.revalidate();
                            p_sql.repaint();
                        }
                        JOptionPane.showMessageDialog(this, "数据库中没有该学生信息！.", "学生信息管理系统", JOptionPane.ERROR_MESSAGE);
                    }
                }

                @Override
                void p_addMbutton() {
                    Menu_button b_clear = new Menu_button("清除输入框",read_ico("F:\\Java课设\\清除按钮.png"),Color.white,Color.decode("#FFA500"));
                    b_clear.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            for (int i = 0; i < input.length; i++) {
                                input[i].setText(null);
                            }
                        }
                    });

                    Menu_button b_toupdate = new Menu_button("将检索结果发送到信息修改",read_ico("F:\\Java课设\\编辑按钮.png"),Color.white, Color.decode("#32CD32"));
                    b_toupdate.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (!nullSql) {
                                int lengths = sqlData.length;
                                sql_update = new Long[lengths];
                                for (int i = 0; i < lengths; i++) {//数组赋值获取学号
                                    sql_update[i] = Long.parseLong((String) sqlData[i][0]);
                                }
                                if (sqlData.length == 1) {
                                    for (int i = 0; i < sqlData[0].length; i++) {
                                        m_panel.input[i].setText((String) sqlData[0][i]);
                                    }
                                }else{//多条则清空
                                    for (int i = 0; i < sqlData[0].length; i++) {
                                        m_panel.input[i].setText("");
                                    }
                                }
                                JOptionPane.showMessageDialog(p_sql, "发送成功，请前往学生信息修改功能区继续操作", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                            } else {
                                JOptionPane.showMessageDialog(p_sql, "你当前还没有检索数据或检索结果为0！", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                    });


                    Menu_button b_todelete = new Menu_button("将检索结果发送到信息删除",read_ico("F:\\Java课设\\删除按钮.png"),Color.white, Color.decode("#FF4500"));
                    b_todelete.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (!nullSql) {
                                if(del_table!=null){//确保表格唯一性
                                    p_del_table.remove(del_table);
                                    p_del_table.revalidate();//重绘
                                }
                                sql_delete = Arrays.copyOf(sqlData,sqlData.length);
                                del_table=getTable(sql_delete);
                                p_del_table.add(del_table);
                                p_del_table.revalidate();//重绘
                                JOptionPane.showMessageDialog(p_sql, "发送成功，请前往学生信息删除功能区继续操作", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                            } else {
                                JOptionPane.showMessageDialog(p_sql, "你当前还没有检索数据或检索结果为0！", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                    });

                    JComboBox<String> c_sort=new JComboBox<>();
                    c_sort.addItem("按学号排序");
                    c_sort.addItem("按年龄排序");
                    c_sort.addItem("按姓名长度排序");
                    Menu_button b_sort = new Menu_button("排序",read_ico("F:\\Java课设\\排序按钮.png"),Color.white,Color.decode("#C71585"));
                    b_sort.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            if (!nullSql) {
                                date_sort(sqlData,c_sort.getSelectedIndex()+1);
                                if (table != null) {
                                    p_sql.remove(table);
                                    p_sql.revalidate();
                                }
                                table = getTable(sqlData);
                                p_sql.add(table);
                                p_sql.revalidate();
                                p_sql.repaint();
                            } else {
                                JOptionPane.showMessageDialog(p_sql, "你当前还没有检索数据或检索结果为0！", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                    });

                    b_panel.add(b_clear);
                    b_panel.add(b_toupdate);
                    b_panel.add(b_todelete);
                    b_panel.add(c_sort);
                    b_panel.add(b_sort);
                }
            });
            //p_add容器布局实现
            p_add.setLayout(new GridLayout(2, 1));
            p_add.add(new M_panel("    • 请输入待添加学生的信息数据:", "添加", "#20B2AA") {
                @Override
                void p_action() {
                    String temp=this.input[4].getText();
                    if (!(temp.equals("女")||temp.equals("男"))){
                        JOptionPane.showMessageDialog(this, "错误的性别.", "学生信息管理系统", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    //添加实现
                    //Mysql insert指令
                    if (!this.hasEmpty() && sql.add_stu(Long.parseLong(input[0].getText()), input[1].getText(), input[2].getText(), Integer.parseInt(input[3].getText()),temp,input[5].getText(), input[6].getText(), input[7].getText(), input[8].getText(), input[9].getText())) {
                        JOptionPane.showMessageDialog(this, "添加学生信息成功", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(this, "添加失败:检查输入的信息是否正确(非空且0<年龄<150)或学生学号是否重复", "学生信息管理系统", JOptionPane.ERROR_MESSAGE);
                    }
                }

                @Override
                void p_addMbutton() {
                    Menu_button b_clear = new Menu_button("清除输入框",read_ico("F:\\Java课设\\清除按钮.png"),Color.white,Color.decode("#FFA500"));
                    b_clear.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            for (int i = 0; i < input.length; i++) {
                                input[i].setText(null);
                            }
                        }
                    });
                    b_panel.add(b_clear);
                }
            });
            //p_update容器布局实现
            p_update.setLayout(new GridLayout(2, 1));
            m_panel = new M_panel("    • 修改学生信息", "修改", "#20B2AA") {
                @Override
                void p_action() {
                    //添加实现
                    //Mysql update指令
                    String[] date=new String[m_panel.input.length];
                    for(int i=0;i<date.length;i++){
                        date[i]=m_panel.input[i].getText();
                    }
                    int count=sql.update_stu(sql_update,date);
                    if(count>0){
                        JOptionPane.showMessageDialog(m_panel, "成功更新 "+count+" 条学生信息.", "学生信息管理系统", JOptionPane.WARNING_MESSAGE);
                    }else{
                        JOptionPane.showMessageDialog(m_panel, "更新失败！请检查更新内容后重试！(学号不得重复)", "学生信息管理系统", JOptionPane.WARNING_MESSAGE);
                    }
                }

                @Override
                void p_addMbutton() {
                    Menu_button b_clear = new Menu_button("清除输入框",read_ico("F:\\Java课设\\清除按钮.png"),Color.white,Color.decode("#FFA500"));
                    b_clear.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            for (int i = 0; i < input.length; i++) {
                                input[i].setText(null);
                            }
                        }
                    });
                    b_panel.add(b_clear);
                }
            };
            p_update.add(m_panel);
            //p_delete容器布局实现
            p_delete.setLayout(new GridLayout(2,1));
            p_del_table=new JPanel();
            p_del_table.setLayout(new GridLayout(1,1));
            JPanel p_del_buttons=new JPanel();
            Menu_button m_sqldel=new Menu_button("删除上述检索到的学生信息",read_ico("F:\\Java课设\\清除按钮.png"),Color.white,Color.decode("#20B2AA"));
            Menu_button m_alldel=new Menu_button("删除数据库中所有学生信息",read_ico("F:\\Java课设\\清除按钮.png"),Color.white,Color.decode("#FF4500"));
            m_sqldel.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int sel=JOptionPane.showConfirmDialog(p_delete,"确定删除上述表格中的 "+sql_delete.length+" 条学生信息?","学生信息管理系统",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
                    if(sel==JOptionPane.YES_OPTION){
                        Long[] del_sno= new Long[sql_delete.length];
                        for(int i=0;i<del_sno.length;i++){
                            del_sno[i]=Long.parseLong((String) sql_delete[i][0]);
                        }
                        int count=sql.del_stu(del_sno);
                        if(count>0){
                            JOptionPane.showMessageDialog(p_delete, "成功删除 "+count+" 条学生信息.", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(p_delete, "删除学生信息失败，请检查该学生信息是否已被删除或使用了过时的删除信息(待删除学生信息已在学生信息更改中更新).", "学生信息管理系统", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            });
            m_alldel.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String temp=JOptionPane.showInputDialog(p_delete,"确定删除数据库的所有学生信息?此操作不可撤销.\n如果你确定要清空所有数据(你知道自己在干啥)\n那么请输入：确认清空","学生信息管理系统:操作警告",JOptionPane.WARNING_MESSAGE);
                    if (temp!=null&&temp.equals("确认清空")) {
                        if (sql.clear_table()) {
                            JOptionPane.showMessageDialog(p_delete, "已成功清空数据库.", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }else{
                        JOptionPane.showMessageDialog(p_delete, "键入了非指定的文本内容，本次操作将不予以生效:未清空数据库", "学生信息管理系统", JOptionPane.WARNING_MESSAGE);
                    }
                }
            });
            p_del_buttons.add(m_sqldel);
            p_del_buttons.add(m_alldel);
            p_delete.add(p_del_table);
            p_delete.add(p_del_buttons);
            //p_backup容器布局实现
            p_backup.setLayout(new GridLayout(2,1));
            p_backup.add(new Back_panel("导出数据库学生信息至文件","导出",Color.decode("#8A2BE2")) {
                @Override
                void Back_action() {
                    String path=paths.getText().trim();//去除占位空格
                    if(sql.dateTobackup(path+"\\backupdate.man")){
                        JOptionPane.showMessageDialog(p_delete, "已成功导出数据库数据.", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                    }else{
                        JOptionPane.showMessageDialog(p_delete, "导出数据库数据失败，请检查导出目录是否存在或拥有访问权限.", "学生信息管理系统", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
            p_backup.add(new Back_panel("导入学生信息数据(非覆盖性)","导入",Color.decode("#32CD32")) {
                @Override
                void Back_action() {
                    String path=paths.getText().trim();//去除占位空格
                    int count=sql.backupTodate(path+"\\backupdate.man");
                    if(count!=-1){
                        JOptionPane.showMessageDialog(p_delete, "已成功将 "+count+" 条数据导入数据库数据.", "学生信息管理系统", JOptionPane.INFORMATION_MESSAGE);
                    }else{
                        JOptionPane.showMessageDialog(p_delete, "导入失败，请检查备份文件是否存在或是否拥有访问权限.", "学生信息管理系统", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });



            getp_right = p_right_temp;
        }
    }

    static class Menu_button extends JButton {
        public Menu_button(String text, Color color1, Color color2) {
            super(text);
            setFont(new Font("微软雅黑", Font.PLAIN, 16));
            setForeground(color1);
            setBackground(color2);
            setBorderPainted(false); // 取消边框绘制
            setFocusPainted(false); // 取消焦点边框绘制
        }
        public Menu_button(String text,ImageIcon icon,Color color1,Color color2) {
            super(text,icon);
            setFont(new Font("微软雅黑", Font.PLAIN, 16));
            setForeground(color1);
            setBackground(color2);
            setBorderPainted(false); // 取消边框绘制
            setFocusPainted(false); // 取消焦点边框绘制
        }
    }

    private abstract class M_panel extends JPanel {
        JTextField[] input;
        JPanel b_panel;
        JScrollPane table;

        public M_panel(String maintitle, String b_name, String color) {
            super();
            JPanel temp = new JPanel();
            setLayout(new BorderLayout());
            temp.setLayout(new GridLayout(5, 4));
            JLabel[] title = new JLabel[11];
            title[0] = new JLabel(maintitle);
            title[0].setFont(new Font("微软雅黑", Font.BOLD, 24));
            title[1] = new JLabel("学号:  ", JLabel.RIGHT);
            title[2] = new JLabel("姓名:  ", JLabel.RIGHT);
            title[3] = new JLabel("班级:  ", JLabel.RIGHT);
            title[4] = new JLabel("年龄:  ", JLabel.RIGHT);
            title[5] = new JLabel("性别:  ", JLabel.RIGHT);
            title[6] = new JLabel("出生日期:  ", JLabel.RIGHT);
            title[7] = new JLabel("地址:  ", JLabel.RIGHT);
            title[8] = new JLabel("电话:  ", JLabel.RIGHT);
            title[9] = new JLabel("邮箱:  ", JLabel.RIGHT);
            title[10] = new JLabel("学院:  ", JLabel.RIGHT);
            input = new JTextField[10];
            input[0] = new JTextField("");
            input[1] = new JTextField("");
            input[2] = new JTextField("");
            input[3] = new JTextField("");
            input[4] = new JTextField("");
            input[5] = new JTextField("");
            input[6] = new JTextField("");
            input[7] = new JTextField("");
            input[8] = new JTextField("");
            input[9] = new JTextField("");
            Font t_font = new Font("微软雅黑", Font.PLAIN, 20);
            for (int i = 1; i < title.length; i++) {
                temp.add(title[i]);
                temp.add(input[i - 1]);
                title[i].setFont(t_font);
                input[i - 1].setFont(t_font);
            }
            b_panel = new JPanel();//南边多个定制按钮容器
            Menu_button b_search = new Menu_button(b_name,read_ico("F:\\Java课设\\执行按钮.png"),Color.white, Color.decode(color));
            b_panel.add(b_search);
            add(title[0], BorderLayout.NORTH);
            add(temp, BorderLayout.CENTER);
            add(b_panel, BorderLayout.SOUTH);
            b_search.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    p_action();
                }
            });
            p_addMbutton();
        }

        abstract void p_action();//抽象方法，用于指定对象通过实现本方法实现特定功能

        abstract void p_addMbutton();//抽象方法，为本Panel界面定制更多的功能按钮

        StringBuffer getSqlwhere() {
            int num = 0;
            StringBuffer sql = new StringBuffer();
            String[] command = {"学号=", "姓名=", "班级=", "年龄=", "性别=", "出生日期=", "地址 like", "电话=", "邮箱=", "学院="};
            for (int i = 0; i < input.length; i++) {
                if (!input[i].getText().isEmpty()) {
                    if (num == 0) {
                        sql.append("where ");
                        num++;
                    } else {
                        sql.append(" and ");
                    }
                    if (i == 0 || i == 3) {//数字，符合mysql语法直接加
                        sql.append(command[i]).append(input[i].getText());
                    } else if (i == 6) {//地址和学院，通配符模糊查询 like
                        sql.append(command[i]).append("'%").append(input[i].getText()).append("%'");
                    } else {//汉字，MySQL要加''
                        sql.append(command[i]).append("'").append(input[i].getText()).append("'");
                    }
                }
            }
            return sql;
        }

        boolean hasEmpty() {//判断输入框是否含有空值
            for (int i = 0; i < input.length; i++) {
                if (input[i].getText().isEmpty()) {
                    return true;
                }
            }
            return false;
        }
    }
    private abstract class Back_panel extends JPanel{
        JTextField paths;
        public Back_panel(String bigtitle,String title,Color color) {
            super();
            setLayout(new GridLayout(3,1));
            JLabel bigTitle=new JLabel(bigtitle);
            Font bigFont=new Font("微软雅黑",Font.BOLD,24);
            bigTitle.setFont(bigFont);
            Font smallFont=new Font("微软雅黑",Font.PLAIN,16);
            paths=new JTextField("F:\\Java课设            ");
            paths.setFont(smallFont);
            Menu_button button=new Menu_button(title,Color.white,color);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Back_action();
                }
            });
            JPanel p1=new JPanel();
            JPanel p2=new JPanel();
            p1.add(bigTitle);
            p2.add(paths);
            p2.add(button);
            add(p1);
            add(p2);
        }
        abstract void Back_action();
    }
    private static ImageIcon read_ico(String file) {
        ImageIcon imageIcon;
        imageIcon = new ImageIcon(file);
        return imageIcon;
    }

    private static void reMBColor(Menu_button a, Menu_button[] x) {
        //将非参数1按钮的背景和颜色还原初始状态
        for (int i = 0; i < x.length; i++) {
            if (x[i] != a) {
                x[i].setForeground(Color.LIGHT_GRAY);
                x[i].setBackground(Color.DARK_GRAY);
            }
        }
    }

    private static JScrollPane getTable(Object[][] date) {
        String[] columnName = {"学号", "姓名", "班级", "年龄", "性别", "出生日期", "地址", "电话", "邮箱", "学院"};
        JTable table = new JTable(date, columnName);
        //创建滚动面板
        return new JScrollPane(table);
    }

    private static void date_sort(Object[][] x, int p) {
        int n = x.length;
        Integer[] y = new Integer[n];
        long[] q = new long[n];
        String[] z = new String[n];
        if (p == 1)//学号
        {
            for (int i = 0; i < n; i++) {
                q[i] = Long.parseLong(((String) x[i][0]).trim());
            }
            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    if (q[j] > q[j + 1]) {
                        long m = q[j];
                        q[j] = q[j + 1];
                        q[j + 1] = m;
                        Object[] temp = x[j];
                        x[j] = x[j + 1];
                        x[j + 1] = temp;
                    }
                }
            }
        } else if (p == 2) {
            for (int i = 0; i < n; i++) {
                y[i] = Integer.parseInt(x[i][3].toString().trim());
            }
            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    if (y[j] > y[j + 1]) {
                        int m = y[j];
                        y[j] = y[j + 1];
                        y[j + 1] = m;
                        Object[] temp = x[j];
                        x[j] = x[j + 1];
                        x[j + 1] = temp;
                    }
                }
            }
        } else if (p == 3) {
            for (int i = 0; i < n; i++) {
                z[i] = String.valueOf(x[i][1]);
            }
            for (int i = 0; i < n; i++) {
                y[i] = z[i].length();
            }
            for (int i = 0; i < n - 1; i++) {
                for (int j = 0; j < n - i - 1; j++) {
                    if (y[j] > y[j + 1]) {
                        int m = y[j];
                        y[j] = y[j + 1];
                        y[j + 1] = m;
                        Object[] temp = x[j];
                        x[j] = x[j + 1];
                        x[j + 1] = temp;
                    }
                }
            }
        }

    }
}
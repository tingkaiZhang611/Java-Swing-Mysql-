import javax.swing.*;
import java.awt.*;

public class Starter {
    public static void main(String[] args) {
        JFrame f = new JFrame("Image Display Example");
        f.setSize(600, 300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.setUndecorated(true);
        ImageIcon imageIcon = new ImageIcon("F:\\Java课设\\启动页面.png");
        JLabel imageLabel = new JLabel(imageIcon);
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(imageLabel, BorderLayout.CENTER);
        f.getContentPane().add(panel);
        f.add(panel);
        f.setVisible(true);
        try {
            Thread.sleep(5500);
        } catch (InterruptedException e) {
            ;
        }
        f.setVisible(false);
        Login l=new Login();
        f=null;
    }
}
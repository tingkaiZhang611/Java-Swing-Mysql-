-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: stu_keshe
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `学生表`
--

DROP TABLE IF EXISTS `学生表`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `学生表` (
  `学号` bigint NOT NULL,
  `姓名` varchar(25) NOT NULL,
  `班级` varchar(25) NOT NULL,
  `年龄` int DEFAULT NULL,
  `性别` enum('男','女') NOT NULL,
  `出生日期` varchar(25) DEFAULT NULL,
  `地址` varchar(50) DEFAULT NULL,
  `电话` varchar(16) DEFAULT NULL,
  `邮箱` varchar(30) DEFAULT NULL,
  `学院` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`学号`),
  CONSTRAINT `学生表_chk_1` CHECK (((`年龄` >= 0) and (`年龄` < 150)))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `学生表`
--

LOCK TABLES `学生表` WRITE;
/*!40000 ALTER TABLE `学生表` DISABLE KEYS */;
INSERT INTO `学生表` VALUES (20220210513211,'陈丰潮','2022运输-1',19,'女','2004-07-21','山东省淄博市','15467389521','cfc1321@qq.com','交通运输学院'),(20230210260511,'黄鹏鑫','2023软工-5',19,'男','2004-05-06','山东省济宁市邹城区','12345678910','xiaochou@qq.com','人工智能学院'),(20230210260532,'张家炜','2023软工-5',18,'男','2005-05-18','江西省宜春市','10987654321','bigchou@qq.com','人工智能学院'),(20230210260615,'王毅','2023软工-6',19,'男','2004-04-30','江西省宜春市','15675423754','Allchou@qq.com','人工智能学院'),(20230210840111,'阿花','2023土木-1',18,'女','2004-10-08','江西省赣州','164279581624','3wa2346@qq.com','土木建筑学院'),(20230210840312,'小丑明','2023土木-3',18,'男','2004-12-21','江西省上饶','15437945611','31598496@qq.com','土木建筑学院');
/*!40000 ALTER TABLE `学生表` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-19 11:41:23
